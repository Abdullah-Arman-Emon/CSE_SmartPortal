from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from fastapi.staticfiles import StaticFiles
import os
from app.core.config import settings  
from fastapi.security import HTTPBearer

app = FastAPI(
    title="Faiak's API",
    version="1.0",
    description="CSEDU SERVER",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For development, or set your frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



app.mount(
    "/resources",
    StaticFiles(directory=settings.resource_hub),  
    name="resources",
)


from app.core.database import Base, engine
from app.Sami.model.userModel import User  # this is important to register the model
from app.Sami.model.teacher import Teacher
from app.Sami.model.course import Course
from app.Sami.model.assignment import Assignment
from app.Sami.model.submission import Submission
from app.Sami.model.activity_log import ActivityLog
from app.Sami.model.schedule import Schedule
from app.Sami.model.research_paper import ResearchPaper
from app.Faiak.model.equipment import Equipment, StudentEquipment
from app.Faiak.model.student import Student
from app.Faiak.model.exam import Exam
from app.Faiak.model.event import Event
from app.Faiak.model.notice import Notice
from app.Faiak.model.missingClassOnMonth import MissingClassOnMonth
from app.Sami.model.meeting import Meeting
from app.Sami.model.rsvp import RSVP
from app.Sami.model.finance_event import FinanceEvent
from app.Sami.model.student_payment import StudentPayment
from app.Faiak.model.admissionform import AdmissionForm



# Create the tables
Base.metadata.create_all(bind=engine)

@app.get('/')
def read_root():
    return {'message': 'CSEDU Backend is running'}

from app.Sami.api import userApi
from app.Sami.api import teacherDashboardApi
from app.Sami.api import teacherProfileApi
from app.Sami.api import courseApi
from app.Sami.api import meetingApi
from app.Sami.api import financeApi
app.include_router(userApi.router)
app.include_router(teacherDashboardApi.router)
app.include_router(teacherProfileApi.router)
app.include_router(courseApi.router)
app.include_router(meetingApi.router)
app.include_router(financeApi.router)

from app.Faiak.api import StudentDashboardApi, StudentSettingsApi, StudentAssignmentApi, StudentMyClassesApi, TeacherMyClassesApi, AdminEquipmentApi, AdminEventApi
from app.Faiak.api import AdminNoticeApi, StudentEquipmentApi, StudentEventApi, UtilityApi, AdminAdmissionHubApi, AdminExamApi, GuestAdmissionHubApi, StudentNoticeApi

app.include_router(StudentDashboardApi.router)
app.include_router(StudentEquipmentApi.router)
app.include_router(StudentEventApi.router)
app.include_router(StudentNoticeApi.router)
app.include_router(StudentSettingsApi.router)
app.include_router(StudentAssignmentApi.router)
app.include_router(StudentMyClassesApi.router)
app.include_router(TeacherMyClassesApi.router)
app.include_router(AdminEquipmentApi.router)
app.include_router(AdminEventApi.router)
app.include_router(AdminNoticeApi.router)
app.include_router(AdminAdmissionHubApi.router)
app.include_router(AdminExamApi.router)
app.include_router(GuestAdmissionHubApi.router)

app.include_router(UtilityApi.router)




